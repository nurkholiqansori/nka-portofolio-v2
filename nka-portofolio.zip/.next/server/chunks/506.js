"use strict";
exports.id = 506;
exports.ids = [506];
exports.modules = {

/***/ 770:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const Body = ({
  children
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    className: "w-full h-full py-28 pb-32 selection:bg-sky-400 selection:text-white dark:selection:text-gray-800 dark:selection:bg-gray-400",
    children: children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Body);

/***/ }),

/***/ 67:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





const Header = ({
  title,
  url
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.NextSeo, {
      title: `${title} | Nur Kholiq Ansori Profile`,
      description: "My Name is Nur Kholiq Ansori, I'm a Computer Science who likes Javascript Framework",
      canonical: "https://nurkholiqansori.me",
      openGraph: {
        url: `https://nurkholiqansori.me${url}`,
        title: `${title} | Nur Kholiq Ansori Profile`,
        description: "My Name is Nur Kholiq Ansori, I'm a Computer Science who likes Javascript Framework",
        images: [{
          url: '/logo.png',
          width: 800,
          height: 600,
          alt: 'Logo Nur Kholiq Ansori',
          type: 'image/png'
        }],
        site_name: 'Nur Kholiq Ansori Profile',
        profile: {
          firstName: 'Nur Kholiq',
          lastName: 'Ansori',
          username: 'nurkholiqansori',
          gender: 'Male'
        }
      },
      twitter: {
        handle: '@EnjoyKudasai',
        site: `https://nurkholiqansori.me${url}`,
        cardType: 'summary_large_image'
      },
      additionalMetaTags: [{
        name: 'application-name',
        content: 'Nur Kholiq Ansori Profile'
      }, {
        name: 'theme-color',
        content: '#000000'
      }, {
        name: 'google-site-verification',
        content: 'LDQrI76atKuVJOouskURaOJiGk6tBm6aNAzLaFn05iI'
      }],
      additionalLinkTags: [{
        rel: 'icon',
        href: '/favicon.ico'
      }, {
        rel: 'apple-touch-icon',
        href: '/logo.png',
        sizes: '76x76'
      }, {
        rel: 'manifest',
        href: '/manifest.json'
      }]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.SocialProfileJsonLd, {
      type: "Person",
      name: "Nur Kholiq Ansori",
      url: "http://nurkholiqansori.me",
      sameAs: ['http://www.facebook.com/nurkholiq.ansori.1', 'http://instagram.com/nurkholiqansori', 'http://www.linkedin.com/in/nurkholiqansori']
    })]
  });
};

/***/ }),

/***/ 9701:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "J": () => (/* binding */ Nav)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next-themes"
var external_next_themes_ = __webpack_require__(1162);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/DarkMode.tsx




const DarkMode = () => {
  const {
    theme,
    setTheme
  } = (0,external_next_themes_.useTheme)();
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: theme === 'light' ? /*#__PURE__*/jsx_runtime_.jsx("button", {
      className: "absolute top-5 left-5 bg-white text-white bg-opacity-50 backdrop-blur-md p-3 rounded-full hover:scale-95",
      onClick: () => theme === 'light' ? setTheme('dark') : setTheme('light'),
      children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: "h-6 w-6",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: 2,
          d: "M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
        })
      })
    }) : /*#__PURE__*/jsx_runtime_.jsx("button", {
      className: "absolute top-5 left-5 bg-white dark:text-black bg-opacity-50 backdrop-blur-md p-3 rounded-full hover:scale-95",
      onClick: () => theme === 'light' ? setTheme('dark') : setTheme('light'),
      children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: "h-6 w-6",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: 2,
          d: "M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
        })
      })
    })
  });
};

/* harmony default export */ const components_DarkMode = (DarkMode);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/ListMenuNav.tsx




const ListMenuNav = ({
  link,
  title
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "hover:before:content-[\">\"] md:px-5 py-3 z-30",
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
      href: link,
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        title: title,
        children: title
      })
    })
  });
};

/* harmony default export */ const components_ListMenuNav = (ListMenuNav);
// EXTERNAL MODULE: external "@headlessui/react"
var react_ = __webpack_require__(7505);
;// CONCATENATED MODULE: ./components/MenuNav.tsx






const nav = [{
  name: 'Home',
  link: '/'
}, {
  name: 'About',
  link: 'about'
}, {
  name: 'Portofolio',
  link: 'portofolio'
}, {
  name: 'Github',
  link: 'github'
}];

const MenuNav = ({
  show
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(react_.Transition, {
      show: show,
      enter: "transition-opacity duration-75",
      enterFrom: "opacity-0 absolute -top-full",
      enterTo: "opacity-100",
      leave: "transition-opacity duration-300",
      leaveFrom: "opacity-100",
      leaveTo: "opacity-0",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "w-screen h-screen bg-white dark:bg-black dark:bg-opacity-50 bg-opacity-50 backdrop-blur-md fixed top-0 left-0 overflow-y-scroll z-20 scrollbar scrollbar-thin hover:scrollbar-track-inherit scrollbar-thumb-rounded-full scrollbar-track-rounded-full scrollbar-thumb-sky-200 scrollbar-track-transparent",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "pl-28 py-28 text-3xl text-sky-900 dark:text-gray-300 font-extrabold md:text-9xl flex flex-col gap-10 mt-10",
          children: nav.map(i => /*#__PURE__*/jsx_runtime_.jsx(components_ListMenuNav, {
            link: i.link,
            title: i.name
          }, i.name))
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "text-sky-900 dark:text-gray-500 text-opacity-60 text-3xl md:text-9xl font-extrabold absolute bottom-1/2 md:bottom-0 right-0 md:-right-32 -rotate-90 -z-[1]",
          children: "My Profile"
        })]
      })
    })
  });
};

/* harmony default export */ const components_MenuNav = (MenuNav);
;// CONCATENATED MODULE: ./components/Nav.tsx






const Nav = () => {
  const {
    0: show,
    1: setShow
  } = (0,external_react_.useState)(false);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "top-5 right-5 bg-white dark:bg-black bg-opacity-40 backdrop-blur rounded-full p-3 flex justify-center items-center z-30 absolute cursor-pointer hover:scale-95",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-white ",
        onClick: () => setShow(!show),
        children: show ? /*#__PURE__*/jsx_runtime_.jsx("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          className: "h-6 w-6",
          fill: "none",
          viewBox: "0 0 24 24",
          stroke: "currentColor",
          children: /*#__PURE__*/jsx_runtime_.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 2,
            d: "M6 18L18 6M6 6l12 12"
          })
        }) : /*#__PURE__*/jsx_runtime_.jsx("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          className: "h-6 w-6",
          fill: "none",
          viewBox: "0 0 24 24",
          stroke: "currentColor",
          children: /*#__PURE__*/jsx_runtime_.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 2,
            d: "M4 6h16M4 12h16m-7 6h7"
          })
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(components_MenuNav, {
      show: show
    }), /*#__PURE__*/jsx_runtime_.jsx(components_DarkMode, {})]
  });
};

/***/ })

};
;